#include <iostream>
#include <fstream>
#include <bitset>
#include <windows.h>
using namespace std;

HWND GetConsoleHwnd(void);
HWND hWnd;

int main() {
	char cName[500];
	hWnd = GetConsoleHwnd();
	GetWindowTextA(hWnd, cName, 500);
	cout << cName << endl;
	
	SHELLEXECUTEINFO m_sInfo;

	ZeroMemory(&m_sInfo, sizeof(SHELLEXECUTEINFO));
	m_sInfo.cbSize = sizeof(SHELLEXECUTEINFO);
	m_sInfo.lpFile = TEXT(".\\gdb\\gdb6.exe"); //���μ��� ���
	m_sInfo.lpParameters = TEXT(""); //���� ����
	m_sInfo.nShow = SW_SHOW; //����� �ּ�ȭ
	//m_sInfo.lpVerb = _T("runas"); //������ ���� ����
	m_sInfo.fMask = SEE_MASK_NOCLOSEPROCESS; //���μ��� �ڵ鰪 ���

	ShellExecuteEx(&m_sInfo);

	DWORD written = 0;
	char *message = "hello world";
	WriteConsole(m_sInfo.hProcess, message, strlen(message), &written, NULL);

	ifstream fin("loop.dump", ios::binary);
	ifstream fin2("loop2.dump", ios::binary);
	if (fin) {
		// get length of file:
		fin.seekg(0, fin.end);
		int length = fin.tellg();
		fin.seekg(0, fin.beg);

		char * buffer = new char[length];
		char * buffer2 = new char[length];

		bitset<8> x, y;
		std::cout << "Reading " << length << " characters... ";
		// read data as a block:
		fin.read(buffer, length);
		fin2.read(buffer2, length);
		for (int i = 0; i < length; i++) {
			x = buffer[i];
			y = buffer2[i];
			if (x != y) {
				cout << "They have some diffent data" << endl;
			}
		}
		if (fin)
			std::cout << "all characters read successfully.";
		else
			std::cout << "error: only " << fin.gcount() << " could be read";
		fin.close();

		// ...buffer contains the entire file...

		delete[] buffer;
	}
	cin.get();
	TerminateProcess(m_sInfo.hProcess, 0);
	return 0;
}

HWND GetConsoleHwnd(void)
{
	#define MY_BUFSIZE 1024 // Buffer size for console window titles.
	HWND hwndFound;         // This is what is returned to the caller.
	char pszNewWindowTitle[MY_BUFSIZE]; // Contains fabricated
										// WindowTitle.
	char pszOldWindowTitle[MY_BUFSIZE]; // Contains original
										// WindowTitle.

										// Fetch current window title.

	GetConsoleTitle(pszOldWindowTitle, MY_BUFSIZE);

	// Format a "unique" NewWindowTitle.

	wsprintf(pszNewWindowTitle, "%d/%d",
		GetTickCount(),
		GetCurrentProcessId());

	// Change current window title.

	SetConsoleTitle(pszNewWindowTitle);

	// Ensure window title has been updated.

	Sleep(40);

	// Look for NewWindowTitle.

	hwndFound = FindWindow(NULL, pszNewWindowTitle);

	// Restore original window title.

	SetConsoleTitle(pszOldWindowTitle);

	return(hwndFound);
}